export const LineChartData = {
  labels: [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
  ],
  datasets: [
    {
      label: "Steps",
      data: [3000, 15000, 4500, 6000, 8000, 7000, 9000, 10000, 2000],
      borderColor: "rgb(75, 192, 192)",
    },
  ],
};
