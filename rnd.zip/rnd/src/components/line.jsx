import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { LineChartData } from "./fake-data";
import { useEffect } from "react";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export const LineGraph = () => {
  useEffect(() => {
    const fetchData = () => {
      const url = "https://dummyapi.online/api/movies";
      fetch(ur, {
        method: "GET",
      })
        .then((data) => {
          console.log("API data");
        })
        .catch((e) => {
          console.log("error");
        });
    };
  }, []);
  const options = {};
  const data = {};
  return <Line options={options} data={LineChartData} />;
};
